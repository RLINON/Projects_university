# Projects_university

#This is a repositery in which I've added all my finished projects. Most of them were assignements from my university
